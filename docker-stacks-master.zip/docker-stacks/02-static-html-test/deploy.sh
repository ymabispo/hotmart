#!/bin/sh
docker stack deploy -c base.yml static-html-stack