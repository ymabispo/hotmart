#!/bin/sh
docker stack deploy -c base.yml sma-stack